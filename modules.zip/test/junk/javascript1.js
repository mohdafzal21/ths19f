function junk1(){
    console.log("I am Absolutely Junk!");
}
function junk2(){
    console.log("I am Super Absolutely Junk!");
}

var stupid = {
    a : 1,
    b : 2
}
const pupu = 22;

module.exports = {
    pupu,
    stupid,
    junk1,
    junk2
};

