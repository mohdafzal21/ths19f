const thuthu = require("../../")
console.log("I dont sleep in class. Sorry!");

