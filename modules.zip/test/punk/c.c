#include<stdio.h>
int main(){
    printf("Hello I am C Langugage");
    return 0;
}